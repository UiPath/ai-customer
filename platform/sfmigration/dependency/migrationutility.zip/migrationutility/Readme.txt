Utilities needed:

Utility Name - "Command to check if already installed"
1. aws s3 -> "aws --version"
2. s3cmd -> "s3cmd --version"
3. bcp utility -> "bcp -v"
4. sqlcmd utility -> "sqlcmd -?"
5. jq utility -> "jq --version"
6. zip -> "zip -v"


Steps :

create a new directory in the Automation suite machine

cd ~
mkdir migrationtools

cd migrationtools

Copy the migrationutility zip file to the migrationtools directory and unzip it.


AWS Utility (reference download link : https://awscli.amazonaws.com/awscli-exe-linux-x86_64.zip):
 
Optional : curl "https://awscli.amazonaws.com/awscli-exe-linux-x86_64.zip" -o "awscliv2.zip"
unzip awscliv2.zip
sudo ./aws/install -b /usr/bin

Optional :
#export PATH=/usr/local/bin:$PATH
#source ~/.bash_profile

S3cmd Utility :

tar -xvf s3cmd-2.2.0.tar.gz

cd s3cmd-2.2.0

Optional : 
sudo python setup.py install 


cp s3cmd /usr/bin/
cp -R S3 /usr/bin/

run command s3cmd

if the below exception is reported then 
/usr/bin/env: ‘python’: No such file or directory


/usr/bin/env: ‘python’: No such file or directory
sudo ln -s /usr/bin/python3 /usr/bin/python
source ~/.bash_profile

and try s3cmd again

BCP and sqlcmd (Reference link : https://docs.microsoft.com/en-us/sql/linux/sql-server-linux-setup-tools?view=sql-server-ver15): 

scp files and then 

sudo yum localinstall msodbcsql-<version>.rpm // version can be copied from the migrationtools directory
sudo yum localinstall mssql-tools-<version>.rpm  // version can be copied from the migrationtools directory

echo 'export PATH="$PATH:/opt/mssql-tools/bin"' >> ~/.bash_profile
echo 'export PATH="$PATH:/opt/mssql-tools/bin"' >> ~/.bashrc

source ~/.bash_profile
source ~/.bashrc


JQ (Reference link : https://github.com/stedolan/jq/releases/download/jq-1.6/jq-linux64) : 
 
chmod +x ./jq

sudo cp jq /usr/bin

jq --version

ZIP(Should already exist if not then please run the below command) :

 sudo dnf install zip


Optional :
GIT(optional) otherwise copy the script directory:

sudo yum install git


Add the below export to the script whereever we are using AWS commands (export, import and storage-validation-check)
export AWS_DEFAULT_REGION=us-west-2


